#include "aggregator.hpp"
#include "dedup.hpp"
#include "quality_filter.hpp"
#include "ranker.hpp"
#include <thread>
#include <mutex>
#include <unordered_map>
#include <algorithm>

namespace gaop {

Aggregator::Aggregator(InstanceManager& instance_manager, SearxClient& client, int concurrency)
    : instance_manager_(instance_manager), client_(client), concurrency_(concurrency) {}

std::vector<SearchResult> Aggregator::search(const std::string& query,
                                              const std::string& categories,
                                              int max_instances) {
    auto instances = instance_manager_.get_ranked_instances(max_instances);

    std::vector<SearchResult> all_results;
    std::mutex results_mutex;

    for (size_t i = 0; i < instances.size(); i += static_cast<size_t>(concurrency_)) {
        std::vector<std::thread> threads;
        size_t end = std::min(i + static_cast<size_t>(concurrency_), instances.size());
        for (size_t j = i; j < end; j++) {
            const auto& instance = instances[j];
            threads.emplace_back([&, instance]() {
                auto results = client_.search(instance.url, query, categories);
                std::lock_guard<std::mutex> lock(results_mutex);
                all_results.insert(all_results.end(), results.begin(), results.end());
            });
        }
        for (auto& t : threads) t.join();
    }

    auto filtered = filter_results(all_results);
    auto unique = deduplicate(filtered);

    std::unordered_map<std::string, double> instance_scores;
    for (const auto& inst : instances) instance_scores[inst.url] = inst.score();

    return rank_results(unique, instance_scores);
}

} // namespace gaop
