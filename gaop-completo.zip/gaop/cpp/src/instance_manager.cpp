#include "instance_manager.hpp"
#include <curl/curl.h>
#include <thread>
#include <vector>
#include <algorithm>
#include <chrono>
#include <iostream>

namespace gaop {

static size_t discard_write(void*, size_t size, size_t nmemb, void*) {
    return size * nmemb;
}

InstanceManager::InstanceManager(std::vector<std::string> primary_urls,
                                  std::vector<std::string> backup_urls,
                                  long timeout_ms,
                                  int min_healthy)
    : backup_pool_(std::move(backup_urls)), timeout_ms_(timeout_ms), min_healthy_(min_healthy) {
    for (auto& url : primary_urls) {
        instances_[url] = Instance{url};
    }
}

void InstanceManager::check_one(Instance& instance) {
    CURL* curl = curl_easy_init();
    if (!curl) return;

    auto start = std::chrono::steady_clock::now();
    curl_easy_setopt(curl, CURLOPT_URL, instance.url.c_str());
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, timeout_ms_);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, discard_write);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "GAOP-HealthCheck/1.0");
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);

    CURLcode res = curl_easy_perform(curl);
    auto end = std::chrono::steady_clock::now();
    double elapsed = std::chrono::duration<double>(end - start).count();

    long http_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);

    if (res == CURLE_OK && http_code < 500) {
        instance.online = true;
        instance.response_time = elapsed;
        instance.success_count += 1;
    } else {
        instance.online = false;
        instance.failure_count += 1;
    }
    instance.last_checked = std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();

    curl_easy_cleanup(curl);
}

void InstanceManager::check_all() {
    std::vector<std::thread> threads;
    std::vector<Instance*> ptrs;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        for (auto& [url, inst] : instances_) ptrs.push_back(&inst);
    }
    for (auto* ptr : ptrs) {
        threads.emplace_back([this, ptr]() { check_one(*ptr); });
        if (threads.size() >= 30) {
            for (auto& t : threads) t.join();
            threads.clear();
        }
    }
    for (auto& t : threads) t.join();
    replace_offline();
}

void InstanceManager::replace_offline() {
    std::lock_guard<std::mutex> lock(mutex_);
    int healthy_count = 0;
    for (auto& [url, inst] : instances_) if (inst.online) healthy_count++;
    if (healthy_count >= min_healthy_) return;

    std::vector<std::string> offline_urls;
    for (auto& [url, inst] : instances_) if (!inst.online) offline_urls.push_back(url);

    for (auto& url : offline_urls) {
        if (backup_pool_.empty()) break;
        std::string new_url = backup_pool_.front();
        backup_pool_.erase(backup_pool_.begin());
        if (instances_.count(new_url)) continue;

        Instance new_instance{new_url};
        check_one(new_instance);
        instances_.erase(url);
        instances_[new_url] = new_instance;
        std::cout << "[GAOP] Substituindo instancia offline " << url << " por " << new_url << "\n";
    }
}

std::vector<Instance> InstanceManager::get_healthy_instances() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<Instance> healthy;
    for (auto& [url, inst] : instances_) if (inst.online) healthy.push_back(inst);
    std::sort(healthy.begin(), healthy.end(), [](const Instance& a, const Instance& b) {
        return a.score() > b.score();
    });
    return healthy;
}

std::vector<Instance> InstanceManager::get_ranked_instances(int limit) const {
    auto ranked = get_healthy_instances();
    if (limit > 0 && static_cast<int>(ranked.size()) > limit) {
        ranked.resize(limit);
    }
    return ranked;
}

} // namespace gaop
