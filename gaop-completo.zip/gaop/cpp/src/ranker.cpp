#include "ranker.hpp"
#include <algorithm>

namespace gaop {

std::vector<SearchResult> rank_results(std::vector<SearchResult> results,
                                        const std::unordered_map<std::string, double>& instance_scores) {
    for (auto& r : results) {
        double instance_score = 0.5;
        auto it = instance_scores.find(r.source_instance);
        if (it != instance_scores.end()) instance_score = it->second;
        double position_score = 1.0 / (1.0 + r.position);
        r.score = instance_score * 0.5 + position_score * 0.5;
    }
    std::sort(results.begin(), results.end(), [](const SearchResult& a, const SearchResult& b) {
        return a.score > b.score;
    });
    return results;
}

} // namespace gaop
