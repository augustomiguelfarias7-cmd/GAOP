#include "gaop.hpp"

namespace gaop {

static InstanceManager make_instance_manager(const GAOPConfig& config) {
    auto instances_pair = config.load_instances();
    return InstanceManager(instances_pair.first, instances_pair.second,
                            config.timeout_ms, config.min_healthy_instances);
}

GAOP::GAOP(GAOPConfig config)
    : config_(std::move(config)),
      instance_manager_(make_instance_manager(config_)),
      client_(config_.timeout_ms, config_.results_per_instance),
      aggregator_(instance_manager_, client_, config_.concurrent_requests) {}

void GAOP::init() {
    instance_manager_.check_all();
}

void GAOP::refresh_instances() {
    instance_manager_.check_all();
}

std::vector<SearchResult> GAOP::search(const std::string& query, const std::string& categories) {
    return aggregator_.search(query, categories);
}

} // namespace gaop
