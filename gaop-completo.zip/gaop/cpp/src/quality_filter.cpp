#include "quality_filter.hpp"
#include <array>
#include <string>

namespace gaop {

static const std::array<std::string, 2> BLOCKED_DOMAINS = {"spamsite.example", "malware.example"};

bool is_quality_result(const SearchResult& result) {
    if (result.url.empty() || result.title.empty()) return false;
    if (result.title.size() < 2) return false;
    for (const auto& domain : BLOCKED_DOMAINS) {
        if (result.url.find(domain) != std::string::npos) return false;
    }
    return true;
}

std::vector<SearchResult> filter_results(const std::vector<SearchResult>& results) {
    std::vector<SearchResult> filtered;
    for (const auto& r : results) {
        if (is_quality_result(r)) filtered.push_back(r);
    }
    return filtered;
}

} // namespace gaop
