#include "searx_client.hpp"
#include <curl/curl.h>
#include <nlohmann/json.hpp>
#include <sstream>

namespace gaop {

static size_t write_callback(void* contents, size_t size, size_t nmemb, void* userp) {
    auto* buffer = static_cast<std::string*>(userp);
    buffer->append(static_cast<char*>(contents), size * nmemb);
    return size * nmemb;
}

static std::string url_encode(CURL* curl, const std::string& value) {
    char* encoded = curl_easy_escape(curl, value.c_str(), static_cast<int>(value.size()));
    std::string result(encoded);
    curl_free(encoded);
    return result;
}

SearxClient::SearxClient(long timeout_ms, int results_per_instance)
    : timeout_ms_(timeout_ms), results_per_instance_(results_per_instance) {}

std::vector<SearchResult> SearxClient::search(const std::string& instance_url,
                                               const std::string& query,
                                               const std::string& categories) {
    std::vector<SearchResult> results;
    CURL* curl = curl_easy_init();
    if (!curl) return results;

    std::string base = instance_url;
    if (!base.empty() && base.back() == '/') base.pop_back();

    std::ostringstream url_stream;
    url_stream << base << "/search?q=" << url_encode(curl, query)
               << "&format=json&categories=" << url_encode(curl, categories);
    std::string full_url = url_stream.str();

    std::string response_buffer;
    curl_easy_setopt(curl, CURLOPT_URL, full_url.c_str());
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, timeout_ms_);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_buffer);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "GAOP/1.0");
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);

    CURLcode res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) return results;

    try {
        auto data = nlohmann::json::parse(response_buffer);
        if (!data.contains("results")) return results;

        int idx = 0;
        for (const auto& item : data["results"]) {
            if (idx >= results_per_instance_) break;

            SearchResult r;
            r.title = item.value("title", std::string(""));
            r.url = item.value("url", std::string(""));
            r.content = item.value("content", std::string(""));

            if (item.contains("img_src") && !item["img_src"].is_null()) {
                r.thumbnail = item["img_src"].get<std::string>();
                r.type = ResultType::Image;
            }

            std::string tmpl = item.value("template", std::string(""));
            if (tmpl.find("video") != std::string::npos) r.type = ResultType::Video;

            if (item.contains("engine") && !item["engine"].is_null()) {
                r.engine = item["engine"].get<std::string>();
            }

            r.source_instance = instance_url;
            r.position = idx;
            results.push_back(r);
            idx++;
        }
    } catch (...) {
        // Erro ao parsear JSON: ignora a instancia e segue para as demais
    }

    return results;
}

} // namespace gaop
