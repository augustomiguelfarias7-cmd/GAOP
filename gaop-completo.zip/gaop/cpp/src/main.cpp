#include "gaop.hpp"
#include <iostream>
#include <curl/curl.h>

int main(int argc, char** argv) {
    curl_global_init(CURL_GLOBAL_ALL);

    std::string query = "open source search engine";
    if (argc > 1) {
        query.clear();
        for (int i = 1; i < argc; i++) {
            if (i > 1) query += " ";
            query += argv[i];
        }
    }

    gaop::GAOPConfig config;
    gaop::GAOP engine(config);
    engine.init();

    auto results = engine.search(query);

    std::cout << "\nResultados para: '" << query << "'\n";
    std::cout << std::string(50, '-') << "\n";

    int count = 0;
    for (const auto& r : results) {
        if (count++ >= 10) break;
        std::cout << "[" << r.score << "] " << r.title << "\n  -> " << r.url << "\n\n";
    }

    curl_global_cleanup();
    return 0;
}
