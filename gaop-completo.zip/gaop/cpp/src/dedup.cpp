#include "dedup.hpp"
#include <unordered_set>
#include <algorithm>
#include <cctype>

namespace gaop {

static std::string normalize_url(const std::string& url) {
    std::string result = url;
    auto scheme_pos = result.find("://");
    if (scheme_pos != std::string::npos) result = result.substr(scheme_pos + 3);
    if (result.rfind("www.", 0) == 0) result = result.substr(4);
    while (!result.empty() && result.back() == '/') result.pop_back();
    std::transform(result.begin(), result.end(), result.begin(), ::tolower);
    return result;
}

std::vector<SearchResult> deduplicate(const std::vector<SearchResult>& results) {
    std::unordered_set<std::string> seen;
    std::vector<SearchResult> unique;
    for (const auto& r : results) {
        std::string key = normalize_url(r.url);
        if (!key.empty() && seen.find(key) == seen.end()) {
            seen.insert(key);
            unique.push_back(r);
        }
    }
    return unique;
}

} // namespace gaop
