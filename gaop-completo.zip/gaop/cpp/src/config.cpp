#include "config.hpp"
#include <fstream>
#include <nlohmann/json.hpp>

namespace gaop {

std::pair<std::vector<std::string>, std::vector<std::string>> GAOPConfig::load_instances() const {
    std::ifstream in(instances_file);
    nlohmann::json data;
    in >> data;

    std::vector<std::string> primary;
    std::vector<std::string> backup;

    if (data.contains("instances")) {
        for (const auto& item : data["instances"]) {
            if (static_cast<int>(primary.size()) >= max_instances) break;
            primary.push_back(item.get<std::string>());
        }
    }
    if (data.contains("backup_instances")) {
        for (const auto& item : data["backup_instances"]) {
            backup.push_back(item.get<std::string>());
        }
    }
    return {primary, backup};
}

} // namespace gaop
