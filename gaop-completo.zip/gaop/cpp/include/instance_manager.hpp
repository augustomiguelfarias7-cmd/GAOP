#pragma once
#include <vector>
#include <string>
#include <unordered_map>
#include <mutex>
#include "models.hpp"

namespace gaop {

// Gerenciador de instancias: health check, ranking e substituicao automatica
class InstanceManager {
public:
    InstanceManager(std::vector<std::string> primary_urls,
                     std::vector<std::string> backup_urls,
                     long timeout_ms,
                     int min_healthy);

    void check_all();
    std::vector<Instance> get_healthy_instances() const;
    std::vector<Instance> get_ranked_instances(int limit = -1) const;

private:
    void check_one(Instance& instance);
    void replace_offline();

    std::unordered_map<std::string, Instance> instances_;
    std::vector<std::string> backup_pool_;
    long timeout_ms_;
    int min_healthy_;
    mutable std::mutex mutex_;
};

} // namespace gaop
