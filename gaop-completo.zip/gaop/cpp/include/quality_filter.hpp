#pragma once
#include <vector>
#include "models.hpp"

namespace gaop {
bool is_quality_result(const SearchResult& result);
std::vector<SearchResult> filter_results(const std::vector<SearchResult>& results);
}
