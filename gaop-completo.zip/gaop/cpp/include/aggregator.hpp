#pragma once
#include <string>
#include <vector>
#include "instance_manager.hpp"
#include "searx_client.hpp"
#include "models.hpp"

namespace gaop {

// Agregador: consulta as melhores instancias em paralelo, filtra, remove
// duplicados e aplica o ranking final por relevancia
class Aggregator {
public:
    Aggregator(InstanceManager& instance_manager, SearxClient& client, int concurrency);
    std::vector<SearchResult> search(const std::string& query,
                                      const std::string& categories = "general",
                                      int max_instances = 50);

private:
    InstanceManager& instance_manager_;
    SearxClient& client_;
    int concurrency_;
};

} // namespace gaop
