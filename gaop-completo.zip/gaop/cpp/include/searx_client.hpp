#pragma once
#include <string>
#include <vector>
#include "models.hpp"

namespace gaop {

// Cliente para consultar instancias SearXNG individuais
class SearxClient {
public:
    SearxClient(long timeout_ms, int results_per_instance);
    std::vector<SearchResult> search(const std::string& instance_url,
                                      const std::string& query,
                                      const std::string& categories = "general");

private:
    long timeout_ms_;
    int results_per_instance_;
};

} // namespace gaop
