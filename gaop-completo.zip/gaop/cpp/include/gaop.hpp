#pragma once
#include <string>
#include <vector>
#include "config.hpp"
#include "instance_manager.hpp"
#include "searx_client.hpp"
#include "aggregator.hpp"
#include "models.hpp"

namespace gaop {

// Classe principal: amarra configuracao, gerenciamento de instancias,
// cliente de busca e agregador
class GAOP {
public:
    explicit GAOP(GAOPConfig config = GAOPConfig());

    void init();
    void refresh_instances();
    std::vector<SearchResult> search(const std::string& query, const std::string& categories = "general");

private:
    GAOPConfig config_;
    InstanceManager instance_manager_;
    SearxClient client_;
    Aggregator aggregator_;
};

} // namespace gaop
