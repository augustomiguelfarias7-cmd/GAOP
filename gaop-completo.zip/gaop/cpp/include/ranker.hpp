#pragma once
#include <vector>
#include <unordered_map>
#include <string>
#include "models.hpp"

namespace gaop {
std::vector<SearchResult> rank_results(std::vector<SearchResult> results,
                                        const std::unordered_map<std::string, double>& instance_scores);
}
