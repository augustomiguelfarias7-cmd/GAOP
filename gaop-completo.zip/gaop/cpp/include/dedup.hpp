#pragma once
#include <vector>
#include "models.hpp"

namespace gaop {
// Remocao de resultados duplicados por URL normalizada
std::vector<SearchResult> deduplicate(const std::vector<SearchResult>& results);
}
