#pragma once
#include <string>
#include <vector>
#include <utility>

namespace gaop {

// Configuracao geral do GAOP: caminho do arquivo de instancias e parametros
struct GAOPConfig {
    std::string instances_file = "instances.json";
    int max_instances = 200;          // ate 200 instancias
    int results_per_instance = 20;    // ate 20 resultados por instancia
    long timeout_ms = 5000;
    int concurrent_requests = 20;
    int min_healthy_instances = 5;    // limite minimo antes de acionar substituicao automatica

    // Retorna (instancias_principais, instancias_backup)
    std::pair<std::vector<std::string>, std::vector<std::string>> load_instances() const;
};

} // namespace gaop
