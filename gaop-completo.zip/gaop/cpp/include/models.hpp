#pragma once
#include <string>
#include <optional>
#include <limits>
#include <cmath>

namespace gaop {

// Instancia SearXNG monitorada pelo GAOP
struct Instance {
    std::string url;
    bool online = true;
    double response_time = std::numeric_limits<double>::infinity();
    int success_count = 0;
    int failure_count = 0;
    long long last_checked = 0;

    // Pontuacao usada no ranking inteligente (confiabilidade + velocidade)
    double score() const {
        int total = success_count + failure_count;
        double reliability = total ? static_cast<double>(success_count) / total : 0.5;
        double speed_score = std::isfinite(response_time) ? 1.0 / (1.0 + response_time) : 0.0;
        return reliability * 0.7 + speed_score * 0.3;
    }
};

enum class ResultType { Link, Image, Video };

struct SearchResult {
    std::string title;
    std::string url;
    std::string content;
    std::optional<std::string> thumbnail;
    std::optional<std::string> engine;
    ResultType type = ResultType::Link;
    std::string source_instance;
    int position = 0;
    double score = 0.0;
};

} // namespace gaop
