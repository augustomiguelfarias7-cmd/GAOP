/**
 * GAOP - Ranking inteligente: combina a pontuacao da instancia (confiabilidade/velocidade)
 * com a posicao original do resultado para gerar a ordenacao final por relevancia.
 */

function rankResults(results, instanceScores) {
  for (const r of results) {
    const instanceScore = instanceScores[r.sourceInstance] ?? 0.5;
    const positionScore = 1 / (1 + r.position);
    r.score = instanceScore * 0.5 + positionScore * 0.5;
  }
  return [...results].sort((a, b) => b.score - a.score);
}

module.exports = { rankResults };
