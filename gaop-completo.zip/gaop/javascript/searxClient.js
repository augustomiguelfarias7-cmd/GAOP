/**
 * GAOP - Cliente para consultar instancias SearXNG individuais.
 * Coleta ate N resultados (links, imagens e videos) por instancia.
 */

const axios = require('axios');
const { SearchResult } = require('./models');

class SearxClient {
  constructor(timeout = 5000, resultsPerInstance = 20) {
    this.timeout = timeout;
    this.resultsPerInstance = resultsPerInstance;
  }

  async search(instanceUrl, query, categories = 'general') {
    const endpoint = instanceUrl.replace(/\/$/, '') + '/search';
    const results = [];

    try {
      const resp = await axios.get(endpoint, {
        params: { q: query, format: 'json', categories },
        headers: { 'User-Agent': 'GAOP/1.0', Accept: 'application/json' },
        timeout: this.timeout,
      });

      const rawResults = (resp.data.results || []).slice(0, this.resultsPerInstance);
      rawResults.forEach((item, idx) => {
        let resultType = 'link';
        if (item.img_src) resultType = 'image';
        else if ((item.template || '').includes('video')) resultType = 'video';

        results.push(
          new SearchResult({
            title: (item.title || '').trim(),
            url: (item.url || '').trim(),
            content: (item.content || '').trim(),
            thumbnail: item.img_src || item.thumbnail || null,
            engine: item.engine || null,
            resultType,
            sourceInstance: instanceUrl,
            position: idx,
          })
        );
      });
    } catch (err) {
      // instancia falhou, apenas ignora e segue para as demais
    }

    return results;
  }
}

module.exports = { SearxClient };
