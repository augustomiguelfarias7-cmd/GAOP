/**
 * GAOP - Classe principal que amarra todos os modulos: configuracao, gerenciamento
 * de instancias, cliente de busca e agregador.
 */

const { GAOPConfig } = require('./config');
const { InstanceManager } = require('./instanceManager');
const { SearxClient } = require('./searxClient');
const { Aggregator } = require('./aggregator');

class GAOP {
  constructor(config = new GAOPConfig()) {
    this.config = config;
    const { primary, backup } = config.loadInstances();

    this.instanceManager = new InstanceManager(
      primary,
      backup,
      config.requestTimeout,
      config.minHealthyInstances
    );
    this.client = new SearxClient(config.requestTimeout, config.resultsPerInstance);
    this.aggregator = new Aggregator(this.instanceManager, this.client, config.concurrentRequests);
  }

  async init() {
    await this.instanceManager.checkAll();
  }

  async refreshInstances() {
    await this.instanceManager.checkAll();
  }

  async search(query, categories = 'general') {
    return this.aggregator.search(query, categories);
  }
}

module.exports = { GAOP };
