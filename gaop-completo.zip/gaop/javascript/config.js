/**
 * GAOP - Configuracao do motor de busca.
 * Carrega a lista de instancias SearXNG (principais e backup) e parametros gerais.
 */

const fs = require('fs');
const path = require('path');

class GAOPConfig {
  constructor(options = {}) {
    this.instancesFile = options.instancesFile || path.join(__dirname, 'instances.json');
    this.maxInstances = options.maxInstances || 200;           // ate 200 instancias
    this.resultsPerInstance = options.resultsPerInstance || 20; // ate 20 resultados por instancia
    this.requestTimeout = options.requestTimeout || 5000;
    this.concurrentRequests = options.concurrentRequests || 20;
    this.minHealthyInstances = options.minHealthyInstances || 5;
  }

  loadInstances() {
    const raw = fs.readFileSync(this.instancesFile, 'utf-8');
    const data = JSON.parse(raw);
    const primary = (data.instances || []).slice(0, this.maxInstances);
    const backup = data.backup_instances || [];
    return { primary, backup };
  }
}

module.exports = { GAOPConfig };
