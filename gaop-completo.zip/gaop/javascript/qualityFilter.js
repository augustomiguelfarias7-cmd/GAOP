/**
 * GAOP - Filtro de qualidade dos resultados.
 */

const BLOCKED_DOMAINS = ['spamsite.example', 'malware.example'];

function isQualityResult(result) {
  if (!result.url || !result.title) return false;
  if (result.title.trim().length < 2) return false;
  return !BLOCKED_DOMAINS.some((domain) => result.url.includes(domain));
}

function filterResults(results) {
  return results.filter(isQualityResult);
}

module.exports = { filterResults, isQualityResult };
