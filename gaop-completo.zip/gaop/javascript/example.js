/**
 * GAOP - Exemplo de uso do motor de busca.
 * Execute: node example.js "sua busca aqui"
 */

const { GAOP } = require('./engine');

(async () => {
  const query = process.argv.slice(2).join(' ') || 'open source search engine';

  const engine = new GAOP();
  await engine.init();
  const results = await engine.search(query);

  console.log(`\nResultados para: '${query}'\n${'-'.repeat(50)}`);
  results.slice(0, 10).forEach((r) => {
    console.log(`[${r.score.toFixed(2)}] ${r.title}\n  -> ${r.url}\n`);
  });
})();
