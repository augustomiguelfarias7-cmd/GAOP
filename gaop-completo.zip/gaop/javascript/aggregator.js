/**
 * GAOP - Agregador: dispara consultas em lotes concorrentes para as melhores
 * instancias, coleta os resultados, filtra, remove duplicados e aplica o ranking final.
 */

const { deduplicate } = require('./dedup');
const { filterResults } = require('./qualityFilter');
const { rankResults } = require('./ranker');

class Aggregator {
  constructor(instanceManager, client, concurrency = 20) {
    this.instanceManager = instanceManager;
    this.client = client;
    this.concurrency = concurrency;
  }

  async search(query, categories = 'general', maxInstances = 50) {
    const instances = this.instanceManager.getRankedInstances(maxInstances);

    const batches = [];
    for (let i = 0; i < instances.length; i += this.concurrency) {
      batches.push(instances.slice(i, i + this.concurrency));
    }

    let allResults = [];
    for (const batch of batches) {
      const batchResults = await Promise.all(
        batch.map((inst) => this.client.search(inst.url, query, categories))
      );
      allResults = allResults.concat(...batchResults);
    }

    const filtered = filterResults(allResults);
    const unique = deduplicate(filtered);
    const instanceScores = Object.fromEntries(instances.map((i) => [i.url, i.score]));

    return rankResults(unique, instanceScores);
  }
}

module.exports = { Aggregator };
