/**
 * GAOP - Modelos de dados: Instancia e Resultado de busca.
 */

class Instance {
  constructor(url) {
    this.url = url;
    this.online = true;
    this.responseTime = Infinity;
    this.successCount = 0;
    this.failureCount = 0;
    this.lastChecked = 0;
  }

  get score() {
    const total = this.successCount + this.failureCount;
    const reliability = total ? this.successCount / total : 0.5;
    const speedScore = this.responseTime !== Infinity ? 1 / (1 + this.responseTime) : 0;
    return reliability * 0.7 + speedScore * 0.3;
  }
}

class SearchResult {
  constructor({
    title,
    url,
    content = '',
    thumbnail = null,
    engine = null,
    resultType = 'link',
    sourceInstance = '',
    position = 0,
  }) {
    this.title = title;
    this.url = url;
    this.content = content;
    this.thumbnail = thumbnail;
    this.engine = engine;
    this.resultType = resultType; // link, image ou video
    this.sourceInstance = sourceInstance;
    this.position = position;
    this.score = 0;
  }
}

module.exports = { Instance, SearchResult };
