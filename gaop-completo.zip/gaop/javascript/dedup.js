/**
 * GAOP - Remocao de resultados duplicados por URL normalizada.
 */

function normalizeUrl(url) {
  try {
    const parsed = new URL(url);
    const host = parsed.host.toLowerCase().replace(/^www\./, '');
    const path = parsed.pathname.replace(/\/$/, '');
    return `${host}${path}`;
  } catch {
    return url;
  }
}

function deduplicate(results) {
  const seen = new Set();
  const unique = [];
  for (const r of results) {
    const key = normalizeUrl(r.url);
    if (key && !seen.has(key)) {
      seen.add(key);
      unique.push(r);
    }
  }
  return unique;
}

module.exports = { deduplicate };
