/**
 * GAOP - Gerenciador de instancias SearXNG.
 *
 * Responsavel por:
 * - Verificar quais instancias estao online/offline (health check)
 * - Substituir automaticamente instancias indisponiveis por instancias de backup
 * - Manter o ranking inteligente das instancias (por confiabilidade e velocidade)
 */

const axios = require('axios');
const { Instance } = require('./models');

class InstanceManager {
  constructor(primaryUrls, backupUrls, timeout = 5000, minHealthy = 5) {
    this.timeout = timeout;
    this.minHealthy = minHealthy;
    this.instances = new Map(primaryUrls.map((url) => [url, new Instance(url)]));
    this.backupPool = [...backupUrls];
  }

  async _checkOne(instance) {
    const start = Date.now();
    try {
      const resp = await axios.get(instance.url, {
        timeout: this.timeout,
        headers: { 'User-Agent': 'GAOP-HealthCheck/1.0' },
        validateStatus: () => true,
      });
      const elapsed = (Date.now() - start) / 1000;
      if (resp.status < 500) {
        instance.online = true;
        instance.responseTime = elapsed;
        instance.successCount += 1;
      } else {
        instance.online = false;
        instance.failureCount += 1;
      }
    } catch (err) {
      instance.online = false;
      instance.failureCount += 1;
    }
    instance.lastChecked = Date.now();
    return instance;
  }

  async checkAll() {
    const checks = [...this.instances.values()].map((inst) => this._checkOne(inst));
    await Promise.all(checks);
    await this._replaceOffline();
  }

  async _replaceOffline() {
    const healthy = [...this.instances.values()].filter((i) => i.online);
    if (healthy.length >= this.minHealthy) return;

    const offlineUrls = [...this.instances.entries()]
      .filter(([, inst]) => !inst.online)
      .map(([url]) => url);

    for (const url of offlineUrls) {
      if (this.backupPool.length === 0) break;
      const newUrl = this.backupPool.shift();
      if (this.instances.has(newUrl)) continue;

      const newInstance = new Instance(newUrl);
      await this._checkOne(newInstance);
      this.instances.delete(url);
      this.instances.set(newUrl, newInstance);
    }
  }

  getHealthyInstances() {
    return [...this.instances.values()]
      .filter((i) => i.online)
      .sort((a, b) => b.score - a.score);
  }

  getRankedInstances(limit) {
    const ranked = this.getHealthyInstances();
    return limit ? ranked.slice(0, limit) : ranked;
  }
}

module.exports = { InstanceManager };
