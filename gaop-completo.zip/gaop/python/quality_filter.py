"""
GAOP - Filtro de qualidade dos resultados.
"""

from typing import List

from models import SearchResult

BLOCKED_DOMAINS = {"spamsite.example", "malware.example"}


def is_quality_result(result: SearchResult) -> bool:
    if not result.url or not result.title:
        return False
    if len(result.title.strip()) < 2:
        return False
    for domain in BLOCKED_DOMAINS:
        if domain in result.url:
            return False
    return True


def filter_results(results: List[SearchResult]) -> List[SearchResult]:
    return [r for r in results if is_quality_result(r)]
