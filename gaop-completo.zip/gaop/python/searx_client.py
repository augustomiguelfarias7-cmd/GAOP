"""
GAOP - Cliente para consultar instancias SearXNG individuais.
Coleta ate N resultados (links, imagens e videos) por instancia.
"""

import logging
from typing import List

import requests

from models import SearchResult

logger = logging.getLogger("gaop.searx_client")


class SearxClient:
    def __init__(self, timeout: float = 5.0, results_per_instance: int = 20):
        self.timeout = timeout
        self.results_per_instance = results_per_instance

    def search(self, instance_url: str, query: str, categories: str = "general") -> List[SearchResult]:
        endpoint = instance_url.rstrip("/") + "/search"
        params = {"q": query, "format": "json", "categories": categories}
        headers = {"User-Agent": "GAOP/1.0", "Accept": "application/json"}
        results: List[SearchResult] = []

        try:
            resp = requests.get(endpoint, params=params, headers=headers, timeout=self.timeout)
            resp.raise_for_status()
            data = resp.json()
            raw_results = data.get("results", [])[: self.results_per_instance]

            for idx, item in enumerate(raw_results):
                result_type = "link"
                if item.get("img_src"):
                    result_type = "image"
                elif "video" in (item.get("template") or ""):
                    result_type = "video"

                results.append(SearchResult(
                    title=(item.get("title") or "").strip(),
                    url=(item.get("url") or "").strip(),
                    content=(item.get("content") or "").strip(),
                    thumbnail=item.get("img_src") or item.get("thumbnail"),
                    engine=item.get("engine"),
                    result_type=result_type,
                    source_instance=instance_url,
                    position=idx,
                ))
        except Exception as exc:
            logger.debug("Consulta falhou em %s: %s", instance_url, exc)

        return results
