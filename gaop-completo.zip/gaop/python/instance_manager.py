"""
GAOP - Gerenciador de instancias SearXNG.

Responsavel por:
- Verificar quais instancias estao online/offline (health check)
- Substituir automaticamente instancias indisponiveis por instancias de backup
- Manter o ranking inteligente das instancias (por confiabilidade e velocidade)
"""

import time
import logging
import concurrent.futures
import requests
from typing import List

from models import Instance

logger = logging.getLogger("gaop.instance_manager")


class InstanceManager:
    def __init__(self, primary_urls: List[str], backup_urls: List[str],
                 timeout: float = 5.0, min_healthy: int = 5):
        self.timeout = timeout
        self.min_healthy = min_healthy
        self.instances = {url: Instance(url=url) for url in primary_urls}
        self.backup_pool = list(backup_urls)

    def _check_one(self, instance: Instance) -> Instance:
        start = time.time()
        try:
            resp = requests.get(
                instance.url,
                timeout=self.timeout,
                headers={"User-Agent": "GAOP-HealthCheck/1.0"},
            )
            elapsed = time.time() - start
            if resp.status_code < 500:
                instance.online = True
                instance.response_time = elapsed
                instance.success_count += 1
            else:
                instance.online = False
                instance.failure_count += 1
        except Exception as exc:
            instance.online = False
            instance.failure_count += 1
            logger.debug("Instancia %s falhou no health check: %s", instance.url, exc)
        instance.last_checked = time.time()
        return instance

    def check_all(self) -> None:
        """Verifica todas as instancias em paralelo (deteccao online/offline)."""
        with concurrent.futures.ThreadPoolExecutor(max_workers=30) as executor:
            futures = [executor.submit(self._check_one, inst) for inst in self.instances.values()]
            for f in concurrent.futures.as_completed(futures):
                f.result()
        self._replace_offline()

    def _replace_offline(self) -> None:
        """Substituicao automatica de instancias indisponiveis pelo pool de backup."""
        healthy = [i for i in self.instances.values() if i.online]
        if len(healthy) >= self.min_healthy:
            return

        offline_urls = [url for url, inst in self.instances.items() if not inst.online]
        for url in offline_urls:
            if not self.backup_pool:
                break
            new_url = self.backup_pool.pop(0)
            if new_url in self.instances:
                continue
            logger.info("Substituindo instancia offline %s por backup %s", url, new_url)
            new_instance = Instance(url=new_url)
            self._check_one(new_instance)
            del self.instances[url]
            self.instances[new_url] = new_instance

    def get_healthy_instances(self) -> List[Instance]:
        healthy = [i for i in self.instances.values() if i.online]
        return sorted(healthy, key=lambda i: i.score, reverse=True)

    def get_ranked_instances(self, limit: int = None) -> List[Instance]:
        ranked = self.get_healthy_instances()
        return ranked[:limit] if limit else ranked
