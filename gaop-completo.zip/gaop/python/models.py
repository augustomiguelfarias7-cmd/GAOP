"""
GAOP - Modelos de dados: Instancia e Resultado de busca.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class Instance:
    url: str
    online: bool = True
    response_time: float = float("inf")
    success_count: int = 0
    failure_count: int = 0
    last_checked: float = 0.0

    @property
    def score(self) -> float:
        """Pontuacao de confiabilidade/velocidade usada no ranking inteligente."""
        total = self.success_count + self.failure_count
        reliability = (self.success_count / total) if total else 0.5
        speed_score = 1.0 / (1.0 + self.response_time) if self.response_time != float("inf") else 0.0
        return (reliability * 0.7) + (speed_score * 0.3)


@dataclass
class SearchResult:
    title: str
    url: str
    content: str = ""
    thumbnail: Optional[str] = None
    engine: Optional[str] = None
    result_type: str = "link"   # link, image ou video
    source_instance: str = ""
    position: int = 0
    score: float = 0.0
