"""
GAOP - Configuracao do motor de busca
Carrega a lista de instancias SearXNG (principais e backup) e parametros gerais.
"""

import json
import os
from dataclasses import dataclass
from typing import List, Tuple

DEFAULT_INSTANCES_FILE = os.path.join(os.path.dirname(__file__), "instances.json")


@dataclass
class GAOPConfig:
    instances_file: str = DEFAULT_INSTANCES_FILE
    max_instances: int = 200          # ate 200 instancias
    results_per_instance: int = 20    # ate 20 resultados por instancia
    request_timeout: float = 5.0
    concurrent_requests: int = 20
    min_healthy_instances: int = 5    # limite minimo antes de acionar substituicao automatica

    def load_instances(self) -> Tuple[List[str], List[str]]:
        """Retorna (instancias_principais, instancias_backup)."""
        with open(self.instances_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        primary = data.get("instances", [])[: self.max_instances]
        backup = data.get("backup_instances", [])
        return primary, backup
