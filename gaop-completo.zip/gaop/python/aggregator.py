"""
GAOP - Agregador: dispara consultas em paralelo para as melhores instancias,
coleta os resultados, filtra, remove duplicados e aplica o ranking final.
"""

import concurrent.futures
import logging
from typing import List

from instance_manager import InstanceManager
from searx_client import SearxClient
from dedup import deduplicate
from quality_filter import filter_results
from ranker import rank_results
from models import SearchResult

logger = logging.getLogger("gaop.aggregator")


class Aggregator:
    def __init__(self, instance_manager: InstanceManager, client: SearxClient, concurrency: int = 20):
        self.instance_manager = instance_manager
        self.client = client
        self.concurrency = concurrency

    def search(self, query: str, categories: str = "general", max_instances: int = 50) -> List[SearchResult]:
        instances = self.instance_manager.get_ranked_instances(limit=max_instances)
        all_results: List[SearchResult] = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=self.concurrency) as executor:
            futures = {
                executor.submit(self.client.search, inst.url, query, categories): inst
                for inst in instances
            }
            for future in concurrent.futures.as_completed(futures):
                try:
                    all_results.extend(future.result())
                except Exception as exc:
                    logger.debug("Erro ao consultar instancia: %s", exc)

        filtered = filter_results(all_results)
        unique = deduplicate(filtered)
        instance_scores = {i.url: i.score for i in instances}
        return rank_results(unique, instance_scores)
