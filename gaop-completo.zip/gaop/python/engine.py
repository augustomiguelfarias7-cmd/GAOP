"""
GAOP - Classe principal que amarra todos os modulos: configuracao, gerenciamento
de instancias, cliente de busca e agregador.
"""

import logging

from config import GAOPConfig
from instance_manager import InstanceManager
from searx_client import SearxClient
from aggregator import Aggregator

logging.basicConfig(level=logging.INFO)


class GAOP:
    def __init__(self, config: GAOPConfig = None):
        self.config = config or GAOPConfig()
        primary, backup = self.config.load_instances()

        self.instance_manager = InstanceManager(
            primary_urls=primary,
            backup_urls=backup,
            timeout=self.config.request_timeout,
            min_healthy=self.config.min_healthy_instances,
        )
        self.client = SearxClient(
            timeout=self.config.request_timeout,
            results_per_instance=self.config.results_per_instance,
        )
        self.aggregator = Aggregator(
            self.instance_manager, self.client, concurrency=self.config.concurrent_requests
        )

        self.instance_manager.check_all()

    def refresh_instances(self):
        """Re-executa o health check e a substituicao automatica de instancias."""
        self.instance_manager.check_all()

    def search(self, query: str, categories: str = "general"):
        return self.aggregator.search(query, categories=categories)
