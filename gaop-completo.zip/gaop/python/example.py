"""
GAOP - Exemplo de uso do motor de busca.
Execute: python example.py "sua busca aqui"
"""

import sys
from engine import GAOP

if __name__ == "__main__":
    query = " ".join(sys.argv[1:]) or "open source search engine"

    engine = GAOP()
    results = engine.search(query)

    print(f"\nResultados para: '{query}'\n" + "-" * 50)
    for r in results[:10]:
        print(f"[{r.score:.2f}] {r.title}\n  -> {r.url}\n")
