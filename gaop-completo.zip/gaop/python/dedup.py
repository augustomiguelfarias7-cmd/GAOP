"""
GAOP - Remocao de resultados duplicados por URL normalizada.
"""

from typing import List
from urllib.parse import urlparse

from models import SearchResult


def _normalize_url(url: str) -> str:
    try:
        parsed = urlparse(url)
        netloc = parsed.netloc.lower().replace("www.", "")
        path = parsed.path.rstrip("/")
        return f"{netloc}{path}"
    except Exception:
        return url


def deduplicate(results: List[SearchResult]) -> List[SearchResult]:
    seen = set()
    unique = []
    for r in results:
        key = _normalize_url(r.url)
        if key and key not in seen:
            seen.add(key)
            unique.append(r)
    return unique
