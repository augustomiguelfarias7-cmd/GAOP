"""
GAOP - Ranking inteligente: combina a pontuacao da instancia (confiabilidade/velocidade)
com a posicao original do resultado para gerar uma ordenacao final por relevancia.
"""

from typing import List, Dict

from models import SearchResult


def rank_results(results: List[SearchResult], instance_scores: Dict[str, float]) -> List[SearchResult]:
    for r in results:
        instance_score = instance_scores.get(r.source_instance, 0.5)
        position_score = 1.0 / (1.0 + r.position)
        r.score = (instance_score * 0.5) + (position_score * 0.5)
    return sorted(results, key=lambda r: r.score, reverse=True)
