# GAOP — Gusto Atlas Open Source Project

Infraestrutura open source de um motor de busca meta-agregador sobre uma rede de
instâncias [SearXNG](https://docs.searxng.org/), implementada em **Python**,
**JavaScript (Node.js)** e **C++**. Cada implementação segue a mesma arquitetura modular:

```
config           -> carrega a lista de instâncias (principais + backup)
models           -> Instance (instância monitorada) e SearchResult (resultado de busca)
instance_manager -> health check, ranking e substituição automática de instâncias
searx_client     -> consulta uma instância SearXNG e coleta até 20 resultados
dedup            -> remove resultados duplicados (por URL normalizada)
quality_filter   -> filtro de qualidade (remove resultados vazios/bloqueados)
ranker           -> ranking inteligente por relevância (confiabilidade + posição)
aggregator       -> dispara consultas em paralelo/concorrência e junta tudo
engine / gaop    -> classe principal (GAOP) que amarra todos os módulos
```

## Recursos implementados

- 🌐 Gerenciamento de até 200 instâncias (configurável em `instances.json`)
- ⚡ Seleção automática das melhores instâncias (ranking por confiabilidade/velocidade)
- 🟢🔴 Detecção de instâncias online/offline (health check)
- 🔄 Substituição automática de instâncias indisponíveis por um pool de backup
- 🏆 Ranking inteligente dos resultados
- ❤️ Monitoramento contínuo (chamando `refresh_instances()` / `refreshInstances()` periodicamente)
- 📥 Coleta de até 20 resultados por instância
- 🧹 Remoção de resultados duplicados
- ⭐ Filtro de qualidade
- 📊 Organização dos resultados por relevância
- 📁 Arquitetura modular (sem interface gráfica, login ou contas — isso fica por conta do Gusto Atlas)

## ⚠️ Importante sobre `instances.json`

O arquivo `instances.json` de cada pasta vem com **5 instâncias públicas de exemplo**
(conhecidas na comunidade SearXNG) e 3 de backup, apenas para demonstração.
Para um ambiente real com até 200 instâncias, substitua pela sua própria lista —
o ideal é usar instâncias que você controla ou uma lista atualizada e testada,
já que instâncias públicas de terceiros mudam de endereço e disponibilidade com frequência.

---

## 🐍 Python

```bash
cd python
pip install -r requirements.txt
python example.py "sua busca aqui"
```

Uso programático:
```python
from engine import GAOP

engine = GAOP()
resultados = engine.search("inteligência artificial")
for r in resultados[:10]:
    print(r.score, r.title, r.url)
```

## 🟨 JavaScript (Node.js)

```bash
cd javascript
npm install
node example.js "sua busca aqui"
```

Uso programático:
```javascript
const { GAOP } = require('./engine');

(async () => {
  const engine = new GAOP();
  await engine.init();
  const resultados = await engine.search('inteligência artificial');
  console.log(resultados.slice(0, 10));
})();
```

## ⚙️ C++

Dependências: `libcurl` e `nlohmann-json` (ex.: `apt install libcurl4-openssl-dev nlohmann-json3-dev`).

```bash
cd cpp
mkdir build && cd build
cmake ..
make
./gaop "sua busca aqui"
```

---

## Nota sobre o Gusto Atlas

O **GAOP**, entregue aqui, é a camada de infraestrutura open source (motor de
busca, sem interface gráfica, login ou contas). O **Gusto Atlas** — com login,
contas de usuário, interface própria, site oficial e exibição organizada de
links/imagens/vídeos — é a camada proprietária construída *sobre* o GAOP,
tipicamente um front-end (web) que consome esse motor como back-end.
